
from random import random
import  sys

if random() < 0.5:
    raise SystemExit("I am lucky")

for line in sys.stdin:
    pass